package com.example.mezbaan;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class CustomersInfo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customers_info);
    }
}